<?php
    $server = "localhost";
    $user = "manisha";
    $password = "Manisha@1234";
    $db = "electric-vehicle";

    $conn = mysqli_connect($server,$user,$password,$db);
    if(!$conn){
        die("Connection Failed ". mysqli_connect_error());
    }
?>

